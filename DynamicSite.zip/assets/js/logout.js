function logout() {
    clearSSdata();
    window.location = "./login.html";
}